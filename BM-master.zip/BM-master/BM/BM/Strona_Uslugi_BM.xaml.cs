﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace BM
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Strona_Uslugi_BM : ContentPage
    {
        public Strona_Uslugi_BM()
        {
            InitializeComponent();
        }
    }
}